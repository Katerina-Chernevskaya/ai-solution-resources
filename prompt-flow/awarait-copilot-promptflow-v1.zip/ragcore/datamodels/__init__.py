from ragcore.datamodels.document import Document
from ragcore.datamodels.search_result import SearchResult
from ragcore.datamodels.datamodels_utils import dataclass_to_dict, results_list_to_docs_list