from typing import List
from ragcore.utils import clip_text, make_valid_json, get_conversation_text, TokenEstimator
import json

MAX_TURN_TOKENS = 1000
TOKEN_ESTIMATOR = TokenEstimator()

def format_generate_reply_inputs_core(query: str, history: List, chunks: List, max_conversation_tokens: int, max_tokens: int) -> object:
  # Construct query text respecting token limits.
  query = clip_text(query, max_tokens) if max_tokens > 10 else ''
  max_tokens -= TOKEN_ESTIMATOR.estimate_tokens(text=query)

  # Construct conversation text respecting token limits.
  conversation = get_conversation_text(history, max_conversation_tokens, MAX_TURN_TOKENS)
  max_tokens -= TOKEN_ESTIMATOR.estimate_tokens(text=conversation)

  documentation_data = get_documentation_text(chunks, max_tokens) if max_tokens > 10 else {'retrieved_documents': '', 'links': ''}

  return {
    'query': query,
    'conversation': conversation,
    'documentation': documentation_data['retrieved_documents'],
    'links': documentation_data['links']  
  }

def get_documentation_text(chunks: List, max_tokens: int) -> str:
  # Convert chunks into JSON string.
  chunks_list = []
  links_dict = {}  # New dictionary for storing only titles under 'links'
  for chunk_index in range(len(chunks)):
    chunk = chunks[chunk_index]
    chunk_text = {
      f'[doc{chunk_index + 1}]': {
        'title': chunk.get('title', ''),
        'content': chunk['content']
      }
    }
    chunks_list.append(chunk_text)
    # Add only the title to the links_dict under the same document key
    links_dict[f'[doc{chunk_index + 1}]'] = {'title': chunk.get('title', '')}
  docs_obj = { 
    'retrieved_documents': chunks_list,
    'links': links_dict  # Include the links dictionary in the final JSON object
  }
  docs_text = json.dumps(docs_obj, ensure_ascii=False)  # ensure_ascii=False to handle non-ASCII characters

  # Clip string and verify still valid JSON.
  docs_text = clip_text(docs_text, max_tokens)
  docs_text = make_valid_json(docs_text)
  #return docs_text
  return docs_obj
