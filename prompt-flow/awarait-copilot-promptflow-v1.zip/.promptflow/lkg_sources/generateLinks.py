from promptflow import tool
import json

@tool
def extract_document_titles(input_data):  
    if isinstance(input_data, str):
        data = json.loads(input_data)
    elif isinstance(input_data, (dict, list)):  
        data = input_data
    else:
        return json.dumps({"error": "Invalid input format"}, ensure_ascii=False)
    
    documents_info = data.get("links", {})  
    
    result = {doc_key: doc_info["title"] for doc_key, doc_info in documents_info.items() if "title" in doc_info}
    
    result_json = json.dumps(result, ensure_ascii=False)
    
    return result_json
